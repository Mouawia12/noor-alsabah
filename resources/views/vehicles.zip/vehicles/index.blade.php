@php
use Carbon\Carbon;
    
@endphp
@extends('layouts.app')

@section('module', 'نظام الحوسبة')
@section('sub', 'الاداري ')
@section('title', 'عرض بيانات المركبات')

@section('content')
<div class="py-5">
    <h2 class="mb-4 section-title">قائمة المركبات</h2>
    <div class="col-12 col-lg-2 col-md-12 col-sm-12 mb-5">
        <label for="manager_id_v" class="form-label   fs-6 fw-bold text-dark mb-3">قائد المجموعة </label>
        <div>
            <select class="form-select fw-bold  " data-control="select2" id="manager_id_v" onchange="window.location.replace('{{route('vehicles.index')}}'+'?manager_id='+this.value)"
                name="manager_id" dir="rtl" >
                <option value="">الكل</option>
                @foreach ($managers as $x)
                    <option value="{{ $x->manager_id }} "  @if(isset($_GET["manager_id"]) and $_GET["manager_id"] == $x->manager_id) selected @endif>{{ $x->manager_name }}</option>
                @endforeach
            </select>
        </div>
    </div>

    {{-- <h3><a class="btn btn-primary" href="{{route('insert_vehicle')}}">إضافة مركبة </a></h3> --}}
        <table class="table" id="vehiclesTable" class="table table-row-bordered gy-5">
            <thead>
                <tr class="fw-semibold fs-6 text-muted">
                    <th scope="col">اسم مالك المركبة</th>
                    <th scope="col">رقم الهوية لصاحب المركبة</th>
                    <th scope="col">نوع المركبة</th>
                    <th scope="col">رقم لوحة</th>
                    <th scope="col">الرقم التسلسلي</th>
                    <th scope="col">الموديل</th>
                    <th scope="col">اللون</th>
                    <th scope="col">صورة رخصة السير</th>
                    <th scope="col">تاريخ انتهاء رخصة السير</th>
                    <th scope="col">اسم الموظف</th>
                    <th scope="col">رقم الجوال للموظف</th>
                    <th scope="col">اسم شركة التأمين</th>
                    <th scope="col">رقم بوليصة التأمين</th>
                    <th scope="col">تاريخ إصدار التأمين</th>
                    <th scope="col">تاريخ انتهاء التأمين</th>
                    <th scope="col">صورة وثيقة التأمين</th>
                    <th scope="col">رقم الوثيقة كرت التشغيل</th>
                    <th scope="col">تاريخ الإصدار كرت التشغيل</th>
                    <th scope="col">تاريخ الانتهاء كرت التشغيل</th>
                    <th scope="col">صورة كرت التشغيل</th>
                    <th scope="col">حالة رخصة السير</th>
                    <th scope="col">حالة تأمين المركبة</th>
                    <th scope="col">حالة كرت التشغيل</th>
                    <th scope="col">الإجراءات</th>

                </tr>
            </thead>
            <tbody>
                @if(count($vehicles))
                @foreach ($vehicles as $vehicle)
                    <tr>
                        <td>{{ $vehicle->owner_name }}</td>
                        <td>{{ $vehicle->owner_id }}</td>
                        <td>{{ $vehicle->vehicle_type }}</td>
                        <td>{{ $vehicle->plate_number }}</td>
                        <td>{{ $vehicle->serial_number }}</td>
                        <td>{{ $vehicle->model }}</td>
                        <td>{{ $vehicle->color }}</td>
                        <td><a href="{{ asset('storage/' . str_replace("public","",$vehicle->license_image)) }}" target="_blank"><img src="{{ asset('storage/' . str_replace("public","",$vehicle->license_image)) }}" alt="صورة رخصة السير" style="width:100px; height:auto;"></a></td>
                        <td>{{ $vehicle->license_expiry }}</td>
                        <td>{{ $vehicle->custodian_name }}</td>
                        <td>{{ $vehicle->custodian_phone }}</td>
                        <td>{{ $vehicle->insurance_company }}</td>
                        <td>{{ $vehicle->policy_number }}</td>
                        <td>{{ $vehicle->insurance_issue }}</td>
                        <td>{{ $vehicle->insurance_expiry }}</td>
                        <td><a href="{{ asset('storage/' . str_replace("public","",$vehicle->insurance_image)) }}" target="_blank"><img src="{{ asset('storage/' . str_replace("public","",$vehicle->insurance_image)) }}" alt="صورة وثيقة التأمين" style="width:100px; height:auto;"></a></td>
                        <td>{{ $vehicle->operation_card_number }}</td>
                        <td>{{ $vehicle->operation_card_issue }}</td>
                        <td>{{ $vehicle->operation_card_expiry }}</td>
                        <td><a href="{{ asset('storage/' . str_replace("public","",$vehicle->operation_card_image)) }}" target="_blank"><img src="{{ asset('storage/' . str_replace("public","",$vehicle->operation_card_image)) }}" alt="صورة كرت التشغيل" style="width:100px; height:auto;"></a></td>
                        <td>{!! (Carbon::parse($vehicle->license_expiry)->diffInDays(\Carbon\Carbon::now()) <= 10 and Carbon::parse($vehicle->license_expiry) > \Carbon\Carbon::now()  )? '<span class="btn btn-warning">ستنتهي</span>' : ((Carbon::parse($vehicle->license_expiry) < \Carbon\Carbon::now() ? '<span class="btn btn-danger">منتهية</span>' : '<span class="btn btn-success">سارية</span>')) !!}</td>
                        <td>{!! (Carbon::parse($vehicle->insurance_expiry)->diffInDays(\Carbon\Carbon::now()) <= 10 and Carbon::parse($vehicle->insurance_expiry) > \Carbon\Carbon::now())  ? '<span class="btn btn-warning">ستنتهي</span>' : ((Carbon::parse($vehicle->insurance_expiry) < \Carbon\Carbon::now() ? '<span class="btn btn-danger">منتهية</span>' : '<span class="btn btn-success">سارية</span>')) !!}</td>
                        <td>{!! (Carbon::parse($vehicle->operation_card_expiry)->diffInDays(\Carbon\Carbon::now()) <= 10 and Carbon::parse($vehicle->operation_card_expiry) > \Carbon\Carbon::now() ) ? '<span class="btn btn-warning">ستنتهي</span>' : ((Carbon::parse($vehicle->operation_card_expiry) < \Carbon\Carbon::now() ? '<span class="btn btn-danger">منتهية</span>' : '<span class="btn btn-success">سارية</span>')) !!}</td>
                        
                        <td>
                            <a href="{{ route('vehicles.edit', $vehicle->id) }}" class="btn btn-primary btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="{{ route('vehicles.destroy', $vehicle->id) }}" method="get" style="display: inline-block;">
                                @csrf
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من أنك تريد حذف هذه المركبة؟')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                    
                @else
                <tr>
                    <td colspan="24">
                        <center>
                            <h2>لا يوجد بيانات لعرضها !</h2>

                        </center>

                    </td>

                </tr>

                    
                @endif
            </tbody>
        </table>
    </div>

    <!-- إضافة Bootstrap JS و Popper.js و jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- إضافة مكتبة DataTables -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>

    <script>
        $(document).ready( function () {
            $('#vehiclesTable').DataTable();
        } );
    </script>
@endsection
